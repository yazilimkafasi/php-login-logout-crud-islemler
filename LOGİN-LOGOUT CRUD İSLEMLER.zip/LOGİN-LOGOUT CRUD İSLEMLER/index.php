<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style-btn.css">
</head>
<body>

	<a href="giris.php"><button name="girisyap" class="btn">Giriş Yap</button></a>
	<a href="kaydol.php"><button name="kaydol" class="btn">Kayıt Ol</button></a>

</body>
</html>